insert into Customer(cus_id, full_name, Item_id)
VALUES

('1', 
'Vamsi', 
NULL),

('2',
 'ravi', 
 NULL),
('3',
 'rahul', 
 NULL),

('4',
 'Vivek', 
 NULL);

insert into items(Item_id, Item_name, orgin_place,price, Item_age, buyer)
VALUES
('p1', 
'Novelty Barware', 
'England',
'$1200', 
'192',
 NULL),

('h1',
 'Depression Glass', 
 'Russia',
 '$10390', 
 '372', 
 NULL);


insert into Seller(Seller_id, Seller_name, Seller_password)
VALUES
('s1',
'mukesh',
'9876'),
('s2',
'mota bhai',
'9123');

insert into DBA(DBA_id, DBA_name, DBA_password)
VALUES
('dba1',
'info_1',
'1234'),
('dba2',
'info_2',
'4321');