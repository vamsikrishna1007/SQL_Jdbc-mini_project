create DATABASE Mart;
USE Mart;

GRANT ALL PRIVILEGES ON Mart.* TO 'root'@'localhost';

create table Customer (
    cus_id VARCHAR(100) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    Item_id VARCHAR(100),
    CONSTRAINT pk_Customer PRIMARY KEY (cus_id)
);

create table items (
    Item_id VARCHAR(100) NOT NULL,
    Item_name VARCHAR(100) NOT NULL,
    orgin_place VARCHAR(100) NOT NULL,
    price VARCHAR(100) NOT NULL,
    Item_age INTEGER NOT NULL,
    buyer VARCHAR(100),
    CONSTRAINT pk_items PRIMARY KEY (Item_id)
);

create table Seller (
    Seller_id VARCHAR(100) NOT NULL,
    Seller_name VARCHAR(100) NOT NULL,
    Seller_password VARCHAR(100) NOT NULL,
    CONSTRAINT pk_Seller PRIMARY KEY (Seller_id)
);

create table DBA (
    DBA_id VARCHAR(100) NOT NULL,
    DBA_name VARCHAR(100) NOT NULL,
    DBA_password VARCHAR(100) NOT NULL,
    CONSTRAINT pk_DBA PRIMARY KEY (DBA_id)
);