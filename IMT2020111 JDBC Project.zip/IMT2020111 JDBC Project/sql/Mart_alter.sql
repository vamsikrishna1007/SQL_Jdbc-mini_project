alter table Customer
    ADD CONSTRAINT fk_Item_id FOREIGN KEY (Item_id) REFERENCES items(Item_id);

alter table items
    ADD CONSTRAINT fk_buyer FOREIGN KEY (buyer) REFERENCES Customer(cus_id);