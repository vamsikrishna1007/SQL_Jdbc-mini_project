alter table Customer
    drop FOREIGN KEY fk_Item_id;

alter table items
    drop FOREIGN KEY fk_buyer;

drop table items;
drop table Seller;
drop table Customer;
drop table DBA;

drop DATABASE Mart;