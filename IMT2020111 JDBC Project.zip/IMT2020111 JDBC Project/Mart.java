// IMT2020111-S.leelavamsikrishna
// ANTIQUEMART-one stop destination for antique items including jewellary to furniture

//To remove paper work and make it computer based and more organized 

// Each antique item is given an unquie id
// there are sellers who has access about all items information.
// they can add /delete antique items info based on avaliable information to maintain online record.
// we store Customers id for future purposes which can be accessed by sellers.



import java.sql.*;
import java.util.Scanner;

public class Mart {

   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
   static final String DB_URL = "jdbc:mysql://localhost/Mart?useSSL=false";
   static final String USER = "root";
   static final String PASS = "slvkslvk";

   public static void main(String[] args) {

      Connection conn = null;
      Statement stmt = null;
      try {
         Class.forName(JDBC_DRIVER);

         conn = DriverManager.getConnection(DB_URL, USER, PASS);
         stmt = conn.createStatement();
         // System.out.println("connecting database");
         Scanner scan = new Scanner(System.in); // create a Scanner object

         clearScreen();
         System.out.println("\nOne stop destination for antique items-Antiquemart\n");
         disp(stmt, scan);

         scan.close();
         stmt.close();
         conn.close();
      } catch (SQLException se) {

      } catch (Exception e) {
         // e.printStackTrace();
      } finally {
         try {
            if (stmt != null)
               stmt.close();
         } catch (SQLException se2) {
         }
         try {
            if (conn != null)
               conn.close();
         } catch (SQLException se) {
            // se.printStackTrace();
         }
      }
   }


   static boolean verify(Statement stmt, Scanner scan, boolean dba) {
      System.out.print("Enter your ID: ");
      String id = scan.nextLine();
      System.out.print("Enter your password: ");
      String password = scan.nextLine();

      clearScreen();
      boolean cnt = false;

      if (dba) {
         String sql = "SELECT * from DBA";
         ResultSet rs = executeSqlStmt(stmt, sql);

         try {
            while (rs.next()) {
               String possible_id = rs.getString("DBA_id");
               String possible_password = rs.getString("DBA_password");

               if (possible_id.equals(id) && password.equals(possible_password)) {
                  cnt = true;
                  break;
               }
            }
         } catch (SQLException se) {
         }
      } else {
         String sql = "SELECT * from Seller";
         ResultSet rs = executeSqlStmt(stmt, sql);

         try {
            while (rs.next()) {
               String check_id = rs.getString("Seller_id");
               String check_pass = rs.getString("Seller_password");

               if (check_id.equals(id) && password.equals(check_pass)) {
                  cnt = true;
                  break;
               }
            }
         } catch (SQLException se) {
         }
      }

      return cnt;
   }

   static void ret_Seller(Statement stmt, Scanner scan) {
      if (verify(stmt, scan, false)) {
         Seller_menu(stmt, scan);
      } else {
         System.out.print("Incorrect password/User id . Press Y to try again and N to navigate back ");
         String input = scan.nextLine();
         if (input.equals("Y"))
            ret_Seller(stmt, scan);
         else
            return;
      }
   }

   static void ret_DBA(Statement stmt, Scanner scan) {
      if (verify(stmt, scan, true)) {
         DBA_menu(stmt, scan);
      } else {
         System.out.print("Incorrect password/User id . Press Y to try again and N to navigate back ");
         String input = scan.nextLine();
         if (input.equals("Y"))
            ret_DBA(stmt, scan);
         else
            return;
      }
   }

   static void Seller_menu(Statement stmt, Scanner scan) {
      System.out.println("Please select appropriate option-");
      System.out.println("1. List of all items");
      System.out.println("2. List of available items");
      System.out.println("3. sell a item");
      System.out.println("4. Add a item");
      System.out.println("5. Delete a item");
      System.out.println("6. Update price of item");
      System.out.println("0. Navigate back");

      System.out.print("\n\nEnter your choice: ");

      int choice = Integer.parseInt(scan.nextLine());
      clearScreen();

      switch (choice) {
         case 0:
            return;
         case 1:
            list_of_items(stmt, scan, false);
            break;
         case 2:
            list_of_items(stmt, scan, true);
            break;
         case 3:
            issue_items(stmt, scan);
            break;
         case 4:
            add_items(stmt, scan);
            break;
         case 5:
            delete_items(stmt, scan);
            break;
         case 6:
            update_item_cost(stmt, scan);
            break;
         default:
            clearScreen();
            System.out.println("Enter a Valid Choice\n");
            break;
      }
      Seller_menu(stmt, scan);
   }

   static void DBA_menu(Statement stmt, Scanner scan) {
      System.out.println("Please select appropriate option-");
      System.out.println("1. List of Customers");
      System.out.println("2. List of Sellers");
      System.out.println("3. Add a Customer");
      System.out.println("4. Delete a Customer");
      System.out.println("5. Add a Seller");
      System.out.println("6. Delete a Seller");
      System.out.println("0. Navigate back");

      System.out.print("\n\nEnter your choice : ");
      int choice = Integer.parseInt(scan.nextLine());
      clearScreen();

      switch (choice) {
         case 0:
            return;
         case 1:
            list_of_Customers(stmt, scan);
            break;
         case 2:
            list_of_Sellers(stmt, scan);
            break;
         case 3:
            add_Customer(stmt, scan);
            break;
         case 4:
            delete_Customer(stmt, scan);
            break;
         case 5:
            add_Seller(stmt, scan);
            break;
         case 6:
            delete_Seller(stmt, scan);
            break;
         default:
            clearScreen();
            System.out.println("Enter a Valid Choice\n");
            break;
      }
      DBA_menu(stmt, scan);
   }

   static boolean list_of_items(Statement stmt, Scanner scan, boolean retAvailable) {
      String sql = "select * from items";
      ResultSet rs = executeSqlStmt(stmt, sql);
      boolean noitemss = true;

      try {
         System.out.println("List of available items:\n");
         while (rs.next()) {
            String id = rs.getString("Item_id");
            String name = rs.getString("Item_name");
            String author = rs.getString("orgin_place");
            String price = rs.getString("price");
            Integer year = rs.getInt("Item_age");
            String buyer = rs.getString("buyer");

            if (retAvailable) {
               if (buyer == null) {
                  System.out.println("Item_ID : " + id);
                  System.out.println("Item Name: " + name);
                  System.out.println("Place of origin: " + author);
                  System.out.println("Price : " + price);
                  System.out.println("Age of item : " + year + " yr");
                  System.out.println("");
                  noitemss = false;
               }
            } else {
               System.out.println("Item_ID : " + id);
               System.out.println("Item Name: " + name);
               System.out.println("Place of origin: " + author);
               System.out.println("Price : " + price);
               System.out.println("Age of item : " + year + " yr");
               System.out.println("Customer_id : " + buyer);
               System.out.println("");
               noitemss = false;
            }
         }

         if (noitemss)
            System.out.println("Sorry ,No items are available as of now\n");

         rs.close();
      } catch (SQLException e) {
         // e.printStackTrace();
      }
      return noitemss;
   }

   static void issue_items(Statement stmt, Scanner scan) {
      try {
         boolean noitemss = list_of_items(stmt, scan, true);
         if (!noitemss) {
            System.out.print("\nEnter items ID : ");
            String id = scan.nextLine();

            System.out.print("Enter Customer id : ");
            String Cus_id_no = scan.nextLine();

            clearScreen();

            String sql = String.format("UPDATE items SET buyer = '%s' WHERE Item_id = '%s'", Cus_id_no, id);
            int result = updateSqlStmt(stmt, sql);

            if (result != 0)
               System.out.println("Product sold to customer successfully\n");
            else
               System.out.println("Something is unusual\n");
         }
      } catch (Exception e) {
         // e.printStackTrace();
      }
   }

   static void add_items(Statement stmt, Scanner scan) {
      try {
         System.out.print("\nEnter product_ID : ");
         String id = scan.nextLine();
         System.out.print("\nEnter items_name : ");
         String name = scan.nextLine();
         System.out.print("\nEnter product_origin : ");
         String author = scan.nextLine();

         System.out.print("\nEnter Price : ");

         String price = scan.nextLine();
         System.out.print("\nEnter Age of Product : ");
         Integer year = Integer.parseInt(scan.nextLine());

         clearScreen();

         String sql = String.format("insert into items VALUES('%s', '%s', '%s','%s' ,'%d', NULL);", id, name, author,
               price, year);
         int result = updateSqlStmt(stmt, sql);

         if (result != 0)
            System.out.println("Product has been added successfully\n");
         else
            System.out.println("Something went wrong\n");
      } catch (Exception e) {
         // e.printStackTrace();
      }
   }

   static void delete_items(Statement stmt, Scanner scan) {
      try {
         System.out.print("\nEnter items ID : ");
         String id = scan.nextLine();

         clearScreen();

         String sql = String.format(
               "DELETE FROM items where Item_id = '%s' and buyer is null" , id);
         int result = updateSqlStmt(stmt, sql);

         if (result != 0)
            System.out.println("Product has been deleted successfully\n");
         else
            System.out.println("Something went wrong\n");
      } catch (Exception e) {
         // e.printStackTrace();
      }
   }

   static void disp(Statement stmt, Scanner scan) {
      System.out.println("Sign in as- ");
      System.out.println("1. Customer");
      System.out.println("2. Seller");
      System.out.println("3. DBA");
      System.out.println("0. Exit Sql connecter");

      System.out.print("\n\nSelect your choice : ");
      int choice = Integer.parseInt(scan.nextLine());
      clearScreen();

      switch (choice) {
         case 0:
            System.out.println("\nThankyou ! Visit Antiquemart again\n\n");
            System.exit(0);
         case 1:
            cus_choice(stmt, scan);
            break;
         case 2:
            ret_Seller(stmt, scan);
            break;
         case 3:
            ret_DBA(stmt, scan);
            break;
         default:
            clearScreen();
            System.out.println("Choose valid option\n");
            break;
      }
      disp(stmt, scan);
   }

   static void cus_choice(Statement stmt, Scanner scan) {
      System.out.println("Select appropriate choice-");
      System.out.println("1.List of available items");
      System.out.println("2.Rules while buying at antiquemart");
      System.out.println("0.Navigate back");

      System.out.print("\n\nEnter your choice : ");
      int choice = Integer.parseInt(scan.nextLine());
      clearScreen();

      switch (choice) {
         case 0:
            return;
         case 1:
            list_of_items(stmt, scan, true);
            break;
         case 2:
            System.out.print("You should have completed 18 years of age and be competent to enter into a contract under Indian contract law. ");
            System.out.println("Payment is an integral part of shopping experience. All payments shall be collected through secured payment in physical mode only after bidding options We accept all prepaid payment options such as all the major Credit Cards, Debit Cards, Net-Banking etc.");
            System.out.println("Hope you have good time");
            break;
         default:
            clearScreen();
            System.out.println("Enter a Valid option\n");
            break;
      }
      cus_choice(stmt, scan);
   }

   static void update_item_cost(Statement stmt, Scanner scan)
   {
      // String sql = "update items set price=? where Item_id = ?;";
      // ResultSet rs = executeSqlStmt(stmt, sql);

      try {

         System.out.println("Update item price:\n");
         System.out.print("Enter Item id : ");
         String id = scan.nextLine();
         System.out.print("Enter updated price : ");
         String price = scan.nextLine();

         

         String sql = String.format("update items set price='%s' where Item_id = '%s';",price,id);
         System.out.println(sql);
         int result = updateSqlStmt(stmt, sql);
        
         if (result != 0)
            System.out.println("Updated successfully\n");
         else
            System.out.println("Error\n");
      } catch (Exception e) {
         // e.printStackTrace();
      }

   }
   
   static void list_of_Customers(Statement stmt, Scanner scan) {
      String sql = "select * from Customer";
      ResultSet rs = executeSqlStmt(stmt, sql);

      try {
         System.out.println("List of Customers:\n");
         while (rs.next()) {
            String id = rs.getString("cus_id");
            String name = rs.getString("full_name");

            System.out.println("id : " + id);
            System.out.println("Full Name: " + name);
            System.out.println("\n");
         }

         rs.close();
      } catch (SQLException e) {
         // e.printStackTrace();
      }
   }

   static void list_of_Sellers(Statement stmt, Scanner scan) {
      String sql = "select * from Seller";
      ResultSet rs = executeSqlStmt(stmt, sql);

      try {
         System.out.println("List of Sellers:\n");
         while (rs.next()) {
            String id = rs.getString("Seller_id");
            String name = rs.getString("Seller_name");

            System.out.println("id : " + id);
            System.out.println("Full Name: " + name);
            System.out.println("\n");
         }

         rs.close();
      } catch (SQLException e) {
         // e.printStackTrace();
      }
   }


   
   static void add_Customer(Statement stmt, Scanner scan) {
      try {
         System.out.print("Enter Customer id : ");
         String id = scan.nextLine();
         System.out.print("Enter Customer name : ");
         String name = scan.nextLine();

         clearScreen();

         String sql = String.format("insert into Customer VALUES('%s', '%s', NULL)", id, name);
         int result = updateSqlStmt(stmt, sql);

         if (result != 0)
            System.out.println("Customer has been added successfully\n");
         else
            System.out.println("Something went wrong\n");
      } catch (Exception e) {
         // e.printStackTrace();
      }
   }

   static void add_Seller(Statement stmt, Scanner scan) {
      try {
         System.out.print("Enter Seller id : ");
         String id = scan.nextLine();
         System.out.print("Enter Seller name : ");
         String name = scan.nextLine();
         System.out.print("Enter Seller password : ");
         String password = scan.nextLine();

         clearScreen();

         String sql = String.format("insert into Seller VALUES('%s', '%s', '%s')", id, name, password);
         int result = updateSqlStmt(stmt, sql);

         if (result != 0)
            System.out.println("Seller added to database successfully\n");
         else
            System.out.println("Seller already present\n");
      } catch (Exception e) {
         // e.printStackTrace();
      }
   }

   static void delete_Customer(Statement stmt, Scanner scan) {
      try {
         System.out.print("Enter Customer id : ");
         String id = scan.nextLine();

         clearScreen();
     
      
      
         String sql = String.format("DELETE FROM Customer where cus_id = '%s' and Item_id is null", id);
         int result = updateSqlStmt(stmt, sql);

         if (result != 0)
            System.out.println("Customer info deleted successfully\n");
         else
            System.out.println("Customer not present in database\n");
      } catch (Exception e) {
            // e.printStackTrace();
      }
   }

   static void delete_Seller(Statement stmt, Scanner scan) {
      try {
         System.out.print("Enter Seller id : ");
         String id = scan.nextLine();

         clearScreen();

         String sql = String.format("DELETE FROM Seller where Seller_id = '%s'", id);
         int result = updateSqlStmt(stmt, sql);

         if (result != 0)
            System.out.println("Seller info deleted successfully \n");
         else
            System.out.println("Seller not present in database\n");
      } catch (Exception e) {

      }
   }

   static ResultSet executeSqlStmt(Statement stmt, String sql) {
      try {
         ResultSet rs = stmt.executeQuery(sql);
         return rs;
      } catch (SQLException se) {
         // se.printStackTrace();
      } catch (Exception e) {
         // e.printStackTrace();
      }
      return null;
   }

   static int updateSqlStmt(Statement stmt, String sql) {
      try {
         System.out.println(sql);
         int rs = stmt.executeUpdate(sql);
         return rs;
      } catch (SQLException se) {
         // se.printStackTrace();
      } catch (Exception e) {
         // e.printStackTrace();
      }
      return 0;
   }

   static void clearScreen() {
      System.out.println("\033[H\033[J");
      System.out.flush();
   }
}

